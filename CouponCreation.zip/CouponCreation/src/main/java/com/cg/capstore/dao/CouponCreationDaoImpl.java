package com.cg.capstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.capstore.model.Coupon;

@Repository
@Component("creationDao")
public class CouponCreationDaoImpl implements CouponCreationDao {

	@PersistenceContext
	EntityManager entityManager;

	public Coupon generateCoupon(Coupon coupon) {
		entityManager.persist(coupon);
		Query query = entityManager.createQuery("select couponId from Coupon where couponName = :name");
		query.setParameter("name", coupon.getCouponName());
		List results = query.getResultList();
		coupon.setCouponId(Integer.parseInt(results.get(0).toString()));
		return coupon;
	}

	public List<Coupon> getCoupons() {
		Query query = entityManager.createQuery("from Coupon");
		List results = query.getResultList();
		return results;
	}

	@Override
	public boolean deleteCoupon(int id) {
		Query query = entityManager.createQuery("delete from Coupon where couponId = :id");
		query.setParameter("id", id);
		int result=query.executeUpdate();
		if(result!=0) {
			return true;
		}
		else {
			return false;
		}
	}
}
