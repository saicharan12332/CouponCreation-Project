package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstore.dao.CouponCreationDao;
import com.cg.capstore.model.Coupon;

@Transactional
@Service
@Component("creationService")
public class CouponCreationServiceImpl implements CouponCreationService {

	@Autowired
	CouponCreationDao creationDao;

	public Coupon generateCoupon(Coupon coupon) {
		return creationDao.generateCoupon(coupon);
	}

	public List<Coupon> getCoupons() {
		return (List<Coupon>) creationDao.getCoupons();
	}

	public boolean deleteCoupons(int id) {
		return creationDao.deleteCoupon(id);
	}
}
