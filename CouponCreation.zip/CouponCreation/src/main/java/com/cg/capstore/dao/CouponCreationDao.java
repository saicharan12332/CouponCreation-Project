package com.cg.capstore.dao;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.cg.capstore.model.Coupon;

public interface CouponCreationDao {
	public Coupon generateCoupon(@RequestBody Coupon coupon);

	public List<Coupon> getCoupons();

	public boolean deleteCoupon(int id);
}
