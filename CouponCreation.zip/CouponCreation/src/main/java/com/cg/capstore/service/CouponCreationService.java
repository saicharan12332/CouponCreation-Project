package com.cg.capstore.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.cg.capstore.model.Coupon;

public interface CouponCreationService {

	public Coupon generateCoupon(@RequestBody Coupon coupon);

	public List<Coupon> getCoupons();

	public boolean deleteCoupons(int id);

}
